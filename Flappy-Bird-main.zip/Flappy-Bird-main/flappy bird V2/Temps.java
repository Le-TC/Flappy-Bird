public class Temps implements Runnable {
    private int PAUSE = 3; // Vitesse de défilement, ajustable pour augmenter la difficulté du jeu

    @Override
    public void run() {
        // Ajuste la vitesse de défilement en fonction du score
        if (Scenejeu.getscore("bird1") >= 10) {
            PAUSE = 6;
        }
        if (Scenejeu.getscore("bird1") >= 30) {
            PAUSE = 4;
        }
        if (Scenejeu.getscore("bird1") >= 50) {
            PAUSE = 2;
        }

        // Déplace et redessine le fond en fonction de la partie en cours
        if (Main.getQ("bird1") == 0) {
            while (!Main.scenejeu.getfin()) {
                Main.scenejeu.xFond--;
                Main.scenejeu.repaint();
                try {
                    Thread.sleep(this.PAUSE);
                } catch (InterruptedException e) {
                    // Gérer l'interruption
                }
            }
        }
        if (Main.getQ("bird1") == 1) {
            while (!Main.scenejeu2.getfin()) {
                Main.scenejeu2.xFond--;
                Main.scenejeu2.repaint();
                try {
                    Thread.sleep(this.PAUSE);
                } catch (InterruptedException e) {
                    // Gérer l'interruption
                }
            }
        }
    }
}