import java.awt.event.*;

// La classe Clavier implémente KeyListener pour gérer les événements clavier
public class Clavier implements KeyListener {

    // Méthode appelée lorsqu'une touche est pressée
    @Override
    public void keyPressed(KeyEvent e) {
        // Vérifie si la touche espace est pressée pour faire monter l'oiseau
        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            if (Main.getQ("bird1") == 0) {
                Main.scenejeu.oiseau.monter(); // Fait monter l'oiseau dans la première scène
            }
            if (Main.getQ("bird1") == 1) {
                Main.scenejeu2.oiseau.monter(); // Fait monter l'oiseau dans la deuxième scène
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent arg0) {
        // Quand une touche est relâchée, rien ne se passe
    }

    @Override
    public void keyTyped(KeyEvent arg0) {
        // Quand une autre touche est pressée et relâchée rapidement, rien ne se passe pour éviter les fausses manipulations
    }
}

