/*
 * cette méthode permet d'afficher le top 3 
 * 
 */

import java.awt.*;
import javax.swing.*;
import javax.swing.ImageIcon;
import java.nio.file.*;
import java.io.*;
import java.util.List;
import java.util.*;
import java.nio.charset.StandardCharsets;

// Classe pour afficher le panneau de fin de jeu avec le classement des meilleurs scores
public class Fin extends JPanel
{
    private String nom;
    private String nom1;
    private String nom2;
    private String nom3;
    private int score;
    private int score1;
    private int score2;
    private int score3;
    private int couleur;
    private int couleur1;
    private int couleur2;
    private int couleur3;
    private ImageIcon iconfond;
    private Image imgfond;

    private Font police;

     // Constructeur initialise les variables et charge l'image de fond
    public Fin(String nom, int score, int couleur) {
        this.nom = nom;
        this.score = score;
        this.nom1 = "Random1";
        this.nom2 = "Random2";
        this.nom3 = "Random3";
        this.score1 = 0;
        this.score2 = 0;
        this.score3 = 0;
        this.couleur = couleur;
        this.couleur1 = 10;
        this.couleur2 = 9;
        this.couleur3 = 8;
        this.police = new Font("Arial", Font.PLAIN, 20);
        this.iconfond = new ImageIcon(getClass().getResource("/Mscores.png"));
        this.imgfond = this.iconfond.getImage();
    }

    // Dessine le fond, les rectangles pour les scores et les noms des joueurs
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(this.imgfond, 0, 0, null);
        rectangle(g, 100, 180);
        rectangle(g, 100, 255);
        rectangle(g, 100, 330);
        nomjoueur(g);
    }

    // Dessine un rectangle pour afficher les scores et les noms des joueurs
    public void rectangle(Graphics g, int x, int y) {
        g.setColor(Color.WHITE);
        g.fillRect(x, y, 200, 50);
    }

    // Dessine les informations des meilleurs joueurs, met à jour le classement
    private void nomjoueur(Graphics g) {
        try {
            best(); // Met à jour le classement des meilleurs joueurs
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
        g.setFont(police);
        g.setColor(Color.BLACK);
        g.drawString(nom1 + " : " + score1, 180, 205);
        g.drawString(nom2 + " : " + score2, 180, 280);
        g.drawString(nom3 + " : " + score3, 180, 355);
        oiseau(g, 100, 190, couleur1);
        oiseau(g, 100, 265, couleur2);
        oiseau(g, 100, 335, couleur3);
    }

    // Lit les données du fichier, met à jour le classement si nécessaire, puis réécrit le fichier
    public void best() throws IOException {
        Path filePath = Paths.get("flappy.txt");
        List<String> datatable = Files.readAllLines(filePath, StandardCharsets.UTF_8);

        int i = 0;
        for (String oneLine : datatable) {
            switch (i) {
                case 0: nom1 = oneLine; break;
                case 1: nom2 = oneLine; break;
                case 2: nom3 = oneLine; break;
                case 3: score1 = Integer.parseInt(oneLine); break;
                case 4: score2 = Integer.parseInt(oneLine); break;
                case 5: score3 = Integer.parseInt(oneLine); break;
                case 6: couleur1 = Integer.parseInt(oneLine); break;
                case 7: couleur2 = Integer.parseInt(oneLine); break;
                case 8: couleur3 = Integer.parseInt(oneLine); break;
            }
            i++;
        }

        // Met à jour les scores et les noms si le nouveau score est meilleur
        if (score1 >= score) {
            if (score2 >= score) {
                if (score3 < score) {
                    score3 = score;
                    nom3 = nom;
                    couleur3 = couleur;
                }
            } else {
                score3 = score2;
                score2 = score;
                nom3 = nom2;
                nom2 = nom;
                couleur3 = couleur2;
                couleur2 = couleur;
            }
        } else {
            score3 = score2;
            score2 = score1;
            score1 = score;
            nom3 = nom2;
            nom2 = nom1;
            nom1 = nom;
            couleur3 = couleur2;
            couleur2 = couleur1;
            couleur1 = couleur;
        }

        // Réécrit les données dans le fichier après avoir effacé son contenu
        try (FileWriter writer = new FileWriter("flappy.txt")) {
            List<String> lines = Arrays.asList(nom1, nom2, nom3, 
                                               Integer.toString(score1), Integer.toString(score2), Integer.toString(score3), 
                                               Integer.toString(couleur1), Integer.toString(couleur2), Integer.toString(couleur3));
            Files.write(Paths.get("flappy.txt"), lines, StandardCharsets.UTF_8);
        }
    }

    // Dessine un oiseau avec une couleur spécifique
    private void oiseau(Graphics g, int x, int y, int couleur) {
        int[] xt = {40 + x, 40 + x, x + 52};
        int[] yt = {12 + y, 24 + y, y + 18};
        g.setColor(Color.YELLOW);
        g.fillPolygon(xt, yt, 3);
        switch (couleur) {
            case 1: g.setColor(Color.RED); break;
            case 2: g.setColor(Color.PINK); break;
            case 3: g.setColor(Color.GREEN); break;
            case 4: g.setColor(Color.BLUE); break;
            default: g.setColor(Color.YELLOW); break;
        }
        g.fillOval(x, y, 40, 35);
        g.setColor(Color.BLACK);
        g.fillOval(x + 25, 4 + y, 10, 10);
        g.setColor(Color.WHITE);
        g.fillOval(x + 2, 15 + y, 10, 10);
    }
}