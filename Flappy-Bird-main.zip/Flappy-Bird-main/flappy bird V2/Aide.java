/*
 * Cette classe permet l'affichage du fond d'aide dans la fenêtre d'information.
 */

import javax.swing.ImageIcon;
import java.awt.Image;
import java.awt.*;
import javax.swing.JPanel;

// La classe Aide hérite de JPanel et affiche une image de fond d'aide
public class Aide extends JPanel {
    
    private ImageIcon fond; // Icône contenant l'image de fond
    private Image imgfond; // Image de fond

    // Constructeur qui initialise l'image de fond à partir d'un fichier ressource
    public Aide() {
        this.fond = new ImageIcon(getClass().getResource("/aide.png"));
        this.imgfond = this.fond.getImage();
    }

    // Méthode pour dessiner l'image de fond
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(this.imgfond, -10, 0, null); // Affiche l'image de fond
    }
}

