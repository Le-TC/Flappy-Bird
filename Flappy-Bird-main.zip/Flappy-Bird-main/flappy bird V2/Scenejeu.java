
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import java.awt.Image;
import java.awt.Graphics;
import java.util.Random;
import java.awt.*;

public class Scenejeu extends JPanel
{
    private ImageIcon fond;
    private Image imgfond;

    public Arbre ArbreHaut1;
    public Arbre ArbreHaut2;
    public Arbre ArbreHaut3;

    public Arbre ArbreBas1;
    public Arbre ArbreBas2;
    public Arbre ArbreBas3;

    private final int bandefond = 400;
    private final int distanceArbre = 400;
    private int ecartArbre = 200;
    public int xFond;
    private int xArbre;

    private Random hasard;

    public Oiseau oiseau;

    private static int score ;
    private Font police;
    private boolean findujeu;

    public Thread chronoEcran;//Gère le temps du jeu
    private int couleur;

    // Constructeur initialisant les éléments de la scène
    public Scenejeu(){
        this.fond = new ImageIcon(getClass().getResource("/cielv2.png"));
        this.imgfond = this.fond.getImage();

        this.xFond = 0; 
        this.xArbre = 300;
        // Initialisation des arbres
        this.ArbreHaut1 = new Arbre(this.xArbre,-80,"/obstacleHaut.png");
        this.ArbreHaut2 = new Arbre(this.xArbre+this.ArbreHaut1.getLargeur("bird1")+this.ecartArbre,-100,"/obstacleHaut.png");
        this.ArbreHaut3 = new Arbre(this.xArbre+(this.ArbreHaut1.getLargeur("bird1")+this.ecartArbre)*2,-130,"/obstacleHaut.png");
        this.ArbreBas1 = new Arbre(this.xArbre,380,"/obstaclebas.png");
        this.ArbreBas2 = new Arbre(this.xArbre+this.ArbreBas1.getLargeur("bird1")+this.ecartArbre,380,"/obstaclebas.png");
        this.ArbreBas3 = new Arbre(this.xArbre+(this.ArbreBas1.getLargeur("bird1")+this.ecartArbre)*2,380,"/obstaclebas.png");

        hasard = new Random();
        this.oiseau = new Oiseau(100,150);

        this.setFocusable(true);
        this.requestFocusInWindow();
        this.addKeyListener(new Clavier());

        this.score=0;
        this.police=new Font("Arial",Font.PLAIN ,40);
        this.findujeu=false;

        chronoEcran =new Thread(new Temps());

    }

    // Méthode pour dessiner les composants de la scène
    public void paintComponent(Graphics g){
        this.deplacement(g);
        this.deplacementArbre(g);
        this.oiseau.sety(this.oiseau.gety()+1,"bird1");      
        oiseau(g,this.oiseau.getx(),this.oiseau.gety());
        this.score();
        g.setFont(police);
        g.drawString(""+score,180,50);

        // Vérifie si le jeu est terminé et affiche un message de fin si nécessaire
        findujeu=Toutescolisions();
        if(findujeu==true){
            g.drawString("Fin du Jeu",80,200);
            chronoEcran.interrupt();// Arrête le thread du chronomètre
            Main.ajouterbouton(Main.btnfin);// Ajoute un bouton pour terminer le jeu
            Main.fenetre.revalidate();
        }

    }


    // dessine les différentes bandes du fond et fait en sorte de faire une rotation sur les 4 bandes afin de faire un cycle du fond
    private void deplacement(Graphics g){ 
        if(this.xFond == -this.bandefond){
            this.xFond = 0;
        }
        g.drawImage(this.imgfond,xFond,0,null);
        g.drawImage(this.imgfond,xFond+this.bandefond,0,null);
        g.drawImage(this.imgfond,xFond+this.bandefond*2,0,null);
        g.drawImage(this.imgfond,xFond+this.bandefond*3,0,null);
    }

    //on utilise la méthode colision de la classe oiseau et on l'applique aux trois niveaux d'arbres en meme temps
    private boolean Toutescolisions(){ 
        boolean findujeu=false;
        if (true==oiseau.collision(ArbreHaut1)||true==oiseau.collision(ArbreHaut2)||true==oiseau.collision(ArbreHaut3)||true==oiseau.collision(ArbreBas1)||true==oiseau.collision(ArbreBas2)||true==oiseau.collision(ArbreBas3)){
            findujeu=true;
        }
        return findujeu;
    }

    //dès que l'on dépasse l'arbre le score augmente
    private void score(){ 
        if(this.ArbreBas1.getx("bird1")+this.ArbreBas1.getLargeur("bird1")==95||this.ArbreBas2.getx("bird1")+this.ArbreBas2.getLargeur("bird1")==95||this.ArbreBas3.getx("bird1")+this.ArbreBas3.getLargeur("bird1")==95){
            this.score++;     
        }
    }

    // Méthode pour déplacer les arbres et les dessiner à l'écran
    private void deplacementArbre(Graphics g) { 
        // Met à jour l'écart entre les arbres en fonction du score
        if(this.score > 40) {
            this.ecartArbre = 100;
        } else if(this.score > 30) {
            this.ecartArbre = 125;
        } else if(this.score > 20) {
            this.ecartArbre = 150;
        } else if(this.score > 10) {
            this.ecartArbre = 175;
        }

        // Déplace les arbres en fonction de leur position actuelle
        this.ArbreHaut1.setx(this.ArbreHaut1.getx("bird1") - 1, "bird1");
        this.ArbreBas1.setx(this.ArbreHaut1.getx("bird1"), "bird1");

        // Réinitialise la position des arbres lorsqu'ils sortent de l'écran
        if(this.ArbreHaut1.getx("bird1") == -100) {
            this.ArbreHaut1.setx(this.ArbreHaut3.getx("bird1") + this.distanceArbre, "bird1");
            this.ArbreHaut1.sety(-130 - 10 * this.hasard.nextInt(10), "bird1");
            this.ArbreBas1.sety(this.ArbreHaut1.gety("bird1") + this.ecartArbre + this.ArbreHaut1.getHauteur("bird1"), "bird1");
        }
        g.drawImage(this.ArbreHaut1.getimgArbre(), this.ArbreHaut1.getx("bird1"), this.ArbreHaut1.gety("bird1"), null);
        g.drawImage(this.ArbreBas1.getimgArbre(), this.ArbreBas1.getx("bird1"), this.ArbreBas1.gety("bird1"), null);

        // Répète le processus pour les deux autres arbres
        this.ArbreHaut2.setx(this.ArbreHaut2.getx("bird1") - 1, "bird1");
        this.ArbreBas2.setx(this.ArbreHaut2.getx("bird1"), "bird1");
        if(this.ArbreHaut2.getx("bird1") == -100) {
            this.ArbreHaut2.setx(this.ArbreHaut1.getx("bird1") + this.distanceArbre, "bird1");
            this.ArbreHaut2.sety(-100 - 10 * this.hasard.nextInt(10), "bird1");
            this.ArbreBas2.sety(this.ArbreHaut2.gety("bird1") + this.ecartArbre + this.ArbreHaut2.getHauteur("bird1"), "bird1");
        }
        g.drawImage(this.ArbreHaut2.getimgArbre(), this.ArbreHaut2.getx("bird1"), this.ArbreHaut2.gety("bird1"), null);
        g.drawImage(this.ArbreBas2.getimgArbre(), this.ArbreBas2.getx("bird1"), this.ArbreBas2.gety("bird1"), null);

        // Répète le processus pour le troisième arbre
        this.ArbreHaut3.setx(this.ArbreHaut3.getx("bird1") - 1, "bird1");
        this.ArbreBas3.setx(this.ArbreHaut3.getx("bird1"), "bird1");
        if(this.ArbreHaut3.getx("bird1") == -100) {
            this.ArbreHaut3.setx(this.ArbreHaut2.getx("bird1") + this.distanceArbre, "bird1");
            this.ArbreHaut3.sety(-80 - 10 * this.hasard.nextInt(10), "bird1");
            this.ArbreBas3.sety(this.ArbreHaut3.gety("bird1") + this.ecartArbre + this.ArbreHaut3.getHauteur("bird1"), "bird1");
        }
        g.drawImage(this.ArbreHaut3.getimgArbre(), this.ArbreHaut3.getx("bird1"), this.ArbreHaut3.gety("bird1"), null);
        g.drawImage(this.ArbreBas3.getimgArbre(), this.ArbreBas3.getx("bird1"), this.ArbreBas3.gety("bird1"), null);
    }

    
    // Méthode pour dessiner l'oiseau à l'écran
    private void oiseau(Graphics g, int x, int y) {
        int couleur = Main.getcouleur("bird1");
        int[] xt = {40 + x, 40 + x, x + 52};
        int[] yt = {12 + y, 24 + y, y + 18};

        // Dessine le corps de l'oiseau
        g.setColor(Color.YELLOW);
        g.fillPolygon(xt, yt, 3);

        // Choisit la couleur de l'oiseau en fonction de la valeur retournée
        switch(couleur) {
            case 1:
                g.setColor(Color.RED);
                break;
            case 2:
                g.setColor(Color.PINK);
                break;
            case 3:
                g.setColor(Color.GREEN);
                break;
            case 4:
                g.setColor(Color.BLUE);
                break;
            default:
                g.setColor(Color.YELLOW); // Valeur par défaut
                break;
        }

        // Dessine les parties supplémentaires de l'oiseau
        g.fillOval(x, y, 40, 35);
        g.setColor(Color.BLACK);
        g.fillOval(x + 25, 4 + y, 10, 10);
        g.setColor(Color.WHITE);
        g.fillOval(x + 2, 15 + y, 10, 10);
    }
    

    // Retourne le thread utilisé pour gérer le temps du jeu
    public Thread getchrono() {
        return this.chronoEcran;
    }

    // Retourne l'état de fin de jeu
    public boolean getfin() {
        return findujeu;
    }

    // Retourne le score du jeu en fonction de l'identifiant passé
    public static int getscore(String mdp) {
        if (mdp.equals("bird1")) {
            return score;
        } else {
            return 0;
        }
    }

}
