import java.awt.*;
import javax.swing.*;

// Classe représentant l'écran de démarrage du jeu
public class Debut extends JPanel {

    // Constructeur de la classe, actuellement vide
    public Debut() {
        
    }

    // Méthode pour dessiner le contenu du panneau
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        oiseau(g, 300, 50); // Dessine l'oiseau à la position (300, 50)
    }

    // Méthode pour dessiner un oiseau à l'écran
    private void oiseau(Graphics g, int x, int y) {
        int couleur = Main.getcouleur("bird1"); // Récupère la couleur de l'oiseau
        int[] xt = {40 + x, 40 + x, x + 52}; // Coordonnées x du triangle (corps de l'oiseau)
        int[] yt = {12 + y, 24 + y, y + 18}; // Coordonnées y du triangle (corps de l'oiseau)

        g.setColor(Color.YELLOW);
        g.fillPolygon(xt, yt, 3); // Dessine le corps de l'oiseau en jaune
        
        // Choisit la couleur en fonction de la valeur retournée
        switch (couleur) {
            case 1:
                g.setColor(Color.RED);
                break;
            case 2:
                g.setColor(Color.PINK);
                break;
            case 3:
                g.setColor(Color.GREEN);
                break;
            case 4:
                g.setColor(Color.BLUE);
                break;
            default:
                g.setColor(Color.YELLOW); // Valeur par défaut
                break;
        }

        g.fillOval(x, y, 40, 35); // Dessine le corps de l'oiseau
        g.setColor(Color.BLACK);
        g.fillOval(x + 25, 4 + y, 10, 10); // Dessine l'œil noir de l'oiseau
        g.setColor(Color.WHITE);
        g.fillOval(x + 2, 15 + y, 10, 10); // Dessine l'œil blanc de l'oiseau
    }
}

