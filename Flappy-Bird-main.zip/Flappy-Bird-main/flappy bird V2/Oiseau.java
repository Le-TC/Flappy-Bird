import java.awt.Image;
import javax.swing.ImageIcon;

// Classe représentant un oiseau dans le jeu
public class Oiseau implements Runnable
{

    private int largeur;
    private int hauteur;
    private int x;
    private int y;
    private int dy; // Vitesse verticale de l'oiseau
    private int poids;

    private int PAUSE = 8; //temps que met le score à s'actualiser

    // Constructeur initialisant l'oiseau avec des valeurs par défaut
    public Oiseau(int x, int y) {
        this.largeur = 34;
        this.hauteur = 20;
        this.x = x;
        this.y = y;
        this.poids = 1;

        // Démarre un nouveau thread pour gérer le mouvement de l'oiseau
        Thread chronoAiles = new Thread(this);
        chronoAiles.start();
    }

    // Retourne la position horizontale de l'oiseau
    public int getx() {
        return x;
    }

    // Définit la position horizontale de l'oiseau si le mot de passe est correct
    public void setx(int x, String mdp) {
        if (mdp.equals("bird1")) {
            this.x = x;
        }
    }

    // Retourne la position verticale de l'oiseau
    public int gety() {
        return y;
    }

    // Définit la position verticale de l'oiseau si le mot de passe est correct
    public void sety(int y, String mdp) {
        if (mdp.equals("bird1")) {
            this.y = y;
        }
    }

    // Retourne la hauteur de l'oiseau
    public int gethauteur() {
        return hauteur;
    }

    // Retourne la largeur de l'oiseau
    public int getlargeur() {
        return largeur;
    }

    // Retourne le poids de l'oiseau
    public int getpoids() {
        return poids;
    }

    // Définit le poids de l'oiseau si le mot de passe est correct
    public void setpoids(String mdp) {
        if (mdp.equals("bird1")) {
            this.poids = Main.getpoids("bird1");
        }
    }

    // Méthode permettant à l'oiseau de monter en fonction de son poids
    public void monter() {
        setpoids("bird1");
        // Réglage de la vitesse de montée en fonction du poids de l'oiseau
        if (this.poids == 1) {
            this.dy = 25;
        } else if (this.poids == 2) {
            this.dy = 35;
        } else {
            this.dy = 35;
        }
    }

    // Méthode privée pour gérer la hauteur de la montée de l'oiseau en fonction de la vitesse dy
    private void Aile(int dy) {
        if (dy > 10) {
            this.y -= 5;
        } else if (dy > 5) {
            this.y -= 2;
        } else if (dy > 1) {
            this.y -= 1;
        }
    }

    // Vérifie si l'oiseau entre en collision avec un arbre
    public boolean collision(Arbre arbre) {
        // Crée une boîte de collision autour de l'oiseau
        if (arbre.gety("bird1") < 100) { // Arbre du haut
            return this.y <= arbre.gety("bird1") + arbre.getHauteur("bird1")
                    && (this.x + this.largeur) / 2 >= arbre.getx("bird1")
                    && this.x <= (arbre.getx("bird1") + arbre.getLargeur("bird1")) / 2;
        } else { // Arbre du bas
            return this.y + this.hauteur >= arbre.gety("bird1")
                    && (this.x + this.largeur) / 2 >= arbre.getx("bird1")
                    && this.x <= (arbre.getx("bird1") + arbre.getLargeur("bird1")) / 2;
        }
    }

    // Exécute le mouvement continu de l'oiseau dans un thread séparé
    @Override
    public void run() {
        setpoids("bird1");
        // Cette méthode fait descendre l'oiseau en fonction du poids et ajuste la difficulté en fonction du score
        while (true) {
            this.Aile(dy);
            if (this.poids == 1) {
                this.dy--;
            } else if (this.poids == 2) {
                this.dy -= 2;
            } else {
                this.dy -= 3;
            }

            // Ajuste le temps entre les mises à jour du score en fonction de l'augmentation score
            if (Scenejeu.getscore("bird1") >= 10) {
                PAUSE = 6;
            }
            if (Scenejeu.getscore("bird1") >= 30) {
                PAUSE = 4;
            }
            if (Scenejeu.getscore("bird1") >= 50) {
                PAUSE = 2;
            }
            try {
                Thread.sleep(PAUSE);
            } catch (InterruptedException ie) {
                // Gère les interruptions du thread
                ie.printStackTrace();
            }
        }
    }

}
