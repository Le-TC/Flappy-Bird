/*
 * Cette classe permet de débuter la partie en lancant la méthode début jeu et sans se perdre dans toutes les méthodes de la classe main
 */
public class debutjeu{
    
    private static Main main;
    
    // Méthode qui initialise le jeu
    public static void debutjeu()
    {
        main=new Main();
        main.Main();
    }

}
