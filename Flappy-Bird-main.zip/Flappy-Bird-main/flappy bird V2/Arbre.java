/*
 * Cette classe permet d'obetenir limage correspondant à l'arbre que l'on souhaite. ce n'est pas la meme image pour un arbre en haut ou en bas de l'image
 */
import java.awt.Image;
import javax.swing.ImageIcon;

public class Arbre
{
    // Déclaration des variables

   private int largeur;
   private int hauteur;
   private int x;
   private int y;
   private String strImage;
   private ImageIcon iconArbre;
   private Image imgArbre;
   
    // Constructeur de la classe Arbre
   public Arbre(int x,int y,String strImage){
       this.largeur = 194;
       this.hauteur = 259;
       this.x = x;
       this.y = y;
       this.strImage = strImage;
       this.iconArbre =new ImageIcon(getClass().getResource(strImage));
       this.imgArbre = this.iconArbre.getImage(); 
   }
    
   // Méthode pour obtenir la hauteur de l'arbre

   public int getHauteur(String mdp){
       if(mdp=="bird1"){
           return hauteur;
        }
        else{
            return 0;
        }
   }
   
   // Méthode pour obtenir la largeur de l'arbre

   public int getLargeur(String mdp){
       if(mdp=="bird1"){
           return largeur;
        }
        else{
            return 0;
        }
   }
   
    // Méthode pour obtenir la coordonnée x de l'arbre

   public int getx(String mdp){
       if(mdp=="bird1"){
            return x;
        }
        else{
            return 0;
        }
   }
   
   // Méthode pour définir la coordonnée x de l'arbre

   public void setx(int x, String mdp){
       if(mdp=="bird1"){
            this.x=x;
        }
   }
   
   // Méthode pour obtenir la coordonnée y de l'arbre

   public int gety(String mdp){
       if(mdp=="bird1"){
            return y;
        }
        else{
            return 0;
        }
   }
   
   // Méthode pour définir la coordonnée y de l'arbre
   
   public void sety(int y, String mdp){
       if(mdp=="bird1"){
            this.y=y;
        }
   }
   
    // Méthode pour obtenir l'image de l'arbre

   public Image getimgArbre(){
       return imgArbre;
   }
}
