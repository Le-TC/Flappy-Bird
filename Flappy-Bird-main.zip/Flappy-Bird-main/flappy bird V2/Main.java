/*
 * Ce jeu a été réalisé par Titouan Couteau, Robin Gendrot, Paul Madere et Nicolas Servan.
 * 
 * 
 * */

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;
import java.awt.*;
import javax.swing.*;

// Classe principale qui gère l'interface utilisateur et l'exécution du jeu
public class Main {

    // Déclaration des composants de l'interface utilisateur
    public static JFrame fenetre;       // Fenêtre principale du jeu
    public static Debut debut;           // Panel affichant le début du jeu
    public static Aide aide;             // Panel affichant l'aide
    public static Scenejeu scenejeu, scenejeu2; // Scènes du jeu, probablement pour différentes étapes ou niveaux
    public static JButton btnfin;        // Bouton pour terminer le jeu
    public static Fin fin;               // Panel affichant les résultats de fin de jeu
    private static int i;                // Variable d'index ou compteur (non utilisée dans ce code)
    private static String nom;           // Nom du joueur
    private static boolean test = false; // Variable de test, probablement pour des conditions de vérification (non utilisée ici)
    private static int couleur;          // Couleur sélectionnée pour l'oiseau
    private static boolean jeuEnCours = true; // Indicateur si le jeu est en cours
    private static int Q = 0;            // Variable de score ou de question (non utilisée ici)
    private static int poids;            // Poids de l'oiseau (non utilisé dans ce code)

    // Méthode principale pour initialiser l'interface utilisateur
    public static void Main() {

        // Création de la fenêtre principale du jeu
        fenetre = new JFrame("flappy bird"); // Titre de la fenêtre
        debut = new Debut(); // Création du panel de début

        couleur = 0; // Initialisation de la couleur sélectionnée

        aide = new Aide(); // Création du panel d'aide
        fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Fermeture de l'application lorsque la fenêtre est fermée
        fenetre.setSize(400, 500); // Définition de la taille de la fenêtre
        fenetre.setResizable(false); // La taille de la fenêtre ne peut pas être modifiée
        fenetre.setAlwaysOnTop(true); // La fenêtre reste au-dessus des autres fenêtres
        fenetre.setLocationRelativeTo(null); // Centrer la fenêtre sur l'écran

        // Création d'un panel pour contenir les composants
        JPanel pane = new JPanel();
        pane.setLayout(null); // Disposition absolue des composants
        fenetre.setContentPane(debut); // Contenu de la fenêtre initialement défini sur le panel "debut"

        pane.setForeground(Color.BLACK); // Définition de la couleur de premier plan du panel
        fenetre.setContentPane(pane); // Ré-affectation du panel avec la disposition absolue

        // Création et ajout des boutons à la fenêtre
        JButton btnchnom = new JButton("Appuyer après saisis !");
        fenetre.getContentPane().add(btnchnom); // Ajoute le bouton au conteneur de la fenêtre
        btnchnom.setBounds(100, 220, 200, 50); // Position et taille du bouton

        JButton btnaide = new JButton("Aide");
        fenetre.getContentPane().add(btnaide);
        btnaide.setBounds(320, 400, 60, 30); // Position et taille du bouton d'aide

        JButton btndebut = new JButton("Début du jeu");
        fenetre.getContentPane().add(btndebut);
        btndebut.setBounds(100, 320, 200, 50); // Position et taille du bouton pour commencer le jeu

        // Création et ajout de labels (étiquettes) à la fenêtre
        JLabel labelcouleur = new JLabel("Choisissez la couleur de votre oiseau");
        fenetre.getContentPane().add(labelcouleur);
        labelcouleur.setBounds(10, 0, 1000, 100); // Position et taille du label de couleur

        JLabel labelcouleur2 = new JLabel("en cliquant sur la couleur souhaitez !");
        fenetre.getContentPane().add(labelcouleur2);
        labelcouleur2.setBounds(10, 10, 1000, 100); // Position et taille du label de couleur (suite)

        // Création et ajout des boutons de sélection de couleur à la fenêtre
        JButton btnrouge = new JButton("");
        btnrouge.setBounds(230, 40, 30, 30);
        fenetre.getContentPane().add(btnrouge);
        btnrouge.setBackground(Color.RED); // Couleur rouge pour ce bouton

        JButton btnnoir = new JButton("");
        btnnoir.setBounds(350, 40, 30, 30);
        fenetre.getContentPane().add(btnnoir);
        btnnoir.setBackground(Color.PINK); // Couleur rose pour ce bouton

        JButton btnbleu = new JButton("");
        btnbleu.setBounds(310, 40, 30, 30);
        fenetre.getContentPane().add(btnbleu);
        btnbleu.setBackground(Color.BLUE); // Couleur bleue pour ce bouton

        JButton btnvert = new JButton("");
        btnvert.setBounds(270, 40, 30, 30);
        fenetre.getContentPane().add(btnvert);
        btnvert.setBackground(Color.GREEN); // Couleur verte pour ce bouton

        // Création et ajout d'un champ de texte pour la saisie du nom
        JTextField chnom = new JTextField(100);
        fenetre.getContentPane().add(chnom);
        chnom.setBounds(300, 180, 50, 20); // Position et taille du champ de texte

        // Création et ajout de labels supplémentaires à la fenêtre
        JLabel chlabel = new JLabel("Bienvenue : ...");
        fenetre.getContentPane().add(chlabel);
        chlabel.setBounds(150, 240, 100, 100); // Position et taille du label de bienvenue

        JLabel regle = new JLabel("Rentrez un nom !");
        fenetre.getContentPane().add(regle);
        regle.setBounds(150, 140, 100, 100); // Position et taille du label demandant le nom

        JLabel btnchniveau = new JLabel("Choix de la difficulté:");
        fenetre.getContentPane().add(btnchniveau);
        btnchniveau.setBounds(140, 70, 120, 50); // Position et taille du label pour le choix de difficulté

        // Création et ajout des boutons pour le choix de la difficulté
        JButton btneasy = new JButton("Facile");
        fenetre.getContentPane().add(btneasy);
        btneasy.setBounds(20, 120, 80, 30); // Position et taille du bouton facile

        JButton btnmoyen = new JButton("Moyen");
        fenetre.getContentPane().add(btnmoyen);
        btnmoyen.setBounds(140, 120, 80, 30); // Position et taille du bouton moyen

        JButton btnhard = new JButton("Difficile");
        fenetre.getContentPane().add(btnhard);
        btnhard.setBounds(260, 120, 110, 30); // Position et taille du bouton difficile

        // Affichage de la fenêtre
        fenetre.setVisible(true);

        // Permet de valider le nom du joueur
        btnchnom.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    // Lorsque le bouton est cliqué, récupérer le texte du champ de texte `chnom`
                    nom = chnom.getText();
                    // Mettre à jour le texte du label `chlabel` pour afficher un message de bienvenue avec le nom du joueur
                    chlabel.setText("Bienvenue : " + nom);
                }
            });

        // Les quatre boutons suivants permettent de choisir la couleur de l'oiseau
        btnrouge.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    // Lorsque le bouton rouge est cliqué, définir la couleur de l'oiseau à 1 (rouge)
                    couleur = 1;
                }
            });

        btnnoir.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    // Lorsque le bouton noir est cliqué, définir la couleur de l'oiseau à 2 (rose)
                    couleur = 2;
                }
            });

        btnvert.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    // Lorsque le bouton vert est cliqué, définir la couleur de l'oiseau à 3 (vert)
                    couleur = 3;
                }
            });

        btnbleu.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    // Lorsque le bouton bleu est cliqué, définir la couleur de l'oiseau à 4 (bleu)
                    couleur = 4;
                }
            });

        // Les trois boutons suivants permettent de choisir la difficulté du jeu
        btneasy.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    // Lorsque le bouton "Facile" est cliqué, définir le poids de l'oiseau à 1 (difficulté facile)
                    poids = 1;
                }
            }); 

        btnmoyen.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    // Lorsque le bouton "Moyen" est cliqué, définir le poids de l'oiseau à 2 (difficulté moyenne)
                    poids = 2;
                }
            });

        btnhard.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    // Lorsque le bouton "Difficile" est cliqué, définir le poids de l'oiseau à 3 (difficulté difficile)
                    poids = 3;
                }
            });

        // Permet d'accéder à une nouvelle fenêtre qui indique les boutons du jeu
        btnaide.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    // Lorsqu'on clique sur le bouton "Aide", on prépare la fenêtre pour afficher l'écran d'aide

                    // Supprime tous les composants existants du conteneur de la fenêtre
                    fenetre.getContentPane().removeAll();
                    fenetre.getContentPane().invalidate();

                    // Définit le panneau d'aide comme le nouveau contenu de la fenêtre
                    fenetre.setContentPane(aide);
                    fenetre.getContentPane().revalidate();

                    // Configure la fenêtre : non redimensionnable, toujours au-dessus, et avec la fermeture standard
                    fenetre.setResizable(false);
                    fenetre.setAlwaysOnTop(true);
                    fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    fenetre.setVisible(true);

                    // Crée un bouton pour commencer une partie et l'ajoute au panneau d'aide
                    JButton btnjeu = new JButton("Commencer une partie");
                    fenetre.getContentPane().add(btnjeu);
                    btnjeu.setBounds(20, 20, 80, 50);

                    // Ajoute un écouteur d'action au bouton "Commencer une partie"
                    btnjeu.addActionListener(new ActionListener(){
                            public void actionPerformed(ActionEvent e){
                                // Lorsqu'on clique sur le bouton "Commencer une partie", on prépare la fenêtre pour l'écran de jeu

                                // Crée une nouvelle instance de Scenejeu
                                scenejeu = new Scenejeu();

                                // Supprime tous les composants existants du conteneur de la fenêtre
                                fenetre.getContentPane().removeAll();
                                fenetre.getContentPane().invalidate();

                                // Définit le panneau de jeu comme le nouveau contenu de la fenêtre
                                fenetre.setContentPane(scenejeu);
                                fenetre.getContentPane().revalidate();

                                // Configure la fenêtre : non redimensionnable, toujours au-dessus, et avec la fermeture standard
                                fenetre.setResizable(false);
                                fenetre.setAlwaysOnTop(true);
                                fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                fenetre.setVisible(true);

                                // Crée un bouton pour commencer le jeu et l'ajoute au panneau de jeu
                                JButton btntest = new JButton("Appuyer pour commencer");
                                fenetre.getContentPane().add(btntest);
                                btntest.setBounds(100, 350, 200, 50);

                                // Ajoute un écouteur d'action au bouton de test
                                btntest.addActionListener(new ActionListener(){
                                        public void actionPerformed(ActionEvent e){
                                            // Lorsqu'on clique sur le bouton de test, démarre le jeu

                                            // Appelle la méthode 'monter' de l'objet oiseau pour initialiser le mouvement de l'oiseau
                                            scenejeu.oiseau.monter();

                                            // Incrémente le compteur pour s'assurer que le bouton de test n'est ajouté qu'une fois
                                            i++;
                                            if (i == 1){
                                                // Retire le bouton de test de l'écran de jeu après son utilisation
                                                fenetre.getContentPane().remove(btntest);
                                            }

                                            // Lance le chronomètre pour le défilement du fond
                                            scenejeu.getchrono().start();

                                            // Crée un bouton pour finir la partie et l'ajoute à l'écran de jeu
                                            btnfin = new JButton("fin");
                                            fenetre.getContentPane().add(btnfin);
                                            btnfin.setBounds(100, 400, 200, 50);

                                            // Ajoute un écouteur d'action au bouton de fin
                                            btnfin.addActionListener(new ActionListener(){
                                                    public void actionPerformed(ActionEvent e){
                                                        // Lorsqu'on clique sur le bouton de fin, affiche l'écran de fin avec le score et les options

                                                        // Crée une nouvelle instance de Fin avec le nom du joueur, le score et la couleur de l'oiseau
                                                        fin = new Fin(nom, scenejeu.getscore("bird1"), couleur);

                                                        // Supprime tous les composants existants du conteneur de la fenêtre
                                                        fenetre.getContentPane().removeAll();
                                                        fenetre.getContentPane().invalidate();

                                                        // Définit le panneau de fin comme le nouveau contenu de la fenêtre
                                                        fenetre.setContentPane(fin);
                                                        fenetre.getContentPane().revalidate();

                                                        // Crée un bouton pour recommencer la partie et l'ajoute à l'écran de fin
                                                        JButton btnrecommencer = new JButton("Voulez vous recommencer ?");
                                                        fenetre.getContentPane().add(btnrecommencer);
                                                        btnrecommencer.setBounds(100, 350, 200, 50);

                                                        // Crée un bouton pour arrêter le jeu et l'ajoute à l'écran de fin
                                                        JButton btnarreter = new JButton("Voulez vous arrêter ?");
                                                        fenetre.getContentPane().add(btnarreter);
                                                        btnarreter.setBounds(100, 400, 200, 50);

                                                        // Crée un bouton pour changer la difficulté et l'ajoute à l'écran de fin
                                                        JButton btnchgtdif = new JButton("Voulez vous changer la difficulté ?");
                                                        fenetre.getContentPane().add(btnchgtdif);
                                                        btnchgtdif.setBounds(100, 450, 200, 50);

                                                        // Ajoute un écouteur d'action au bouton d'arrêt
                                                        btnarreter.addActionListener(new ActionListener(){
                                                                public void actionPerformed(ActionEvent e){
                                                                    // Lorsqu'on clique sur le bouton d'arrêt, ferme la fenêtre du jeu
                                                                    fenetre.dispose();
                                                                    jeuEnCours = false;
                                                                }
                                                            });

                                                        // Ajoute un écouteur d'action au bouton de recommencement
                                                        btnrecommencer.addActionListener(new ActionListener(){
                                                                public void actionPerformed(ActionEvent e){
                                                                    // Lorsqu'on clique sur le bouton de recommencement, relance une nouvelle partie

                                                                    Q = 1;
                                                                    i = 0;

                                                                    // Crée une nouvelle instance de Scenejeu pour la nouvelle partie
                                                                    scenejeu2 = new Scenejeu();

                                                                    // Supprime tous les composants existants du conteneur de la fenêtre
                                                                    fenetre.getContentPane().removeAll();
                                                                    fenetre.getContentPane().invalidate();

                                                                    // Définit le panneau de jeu comme le nouveau contenu de la fenêtre
                                                                    fenetre.setContentPane(scenejeu2);
                                                                    fenetre.getContentPane().revalidate();

                                                                    // Configure la fenêtre : non redimensionnable, toujours au-dessus, et avec la fermeture standard
                                                                    fenetre.setResizable(false);
                                                                    fenetre.setAlwaysOnTop(true);
                                                                    fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                                                    fenetre.setVisible(true);

                                                                    // Crée un bouton pour commencer la partie dans la nouvelle instance de Scenejeu et l'ajoute au panneau de jeu
                                                                    JButton btntest2 = new JButton("Appuyer pour commencer");
                                                                    fenetre.getContentPane().add(btntest2);
                                                                    btntest2.setBounds(100, 350, 200, 50);

                                                                    // Ajoute un écouteur d'action au nouveau bouton de test
                                                                    btntest2.addActionListener(new ActionListener(){
                                                                            public void actionPerformed(ActionEvent e){
                                                                                // Lorsqu'on clique sur le bouton de test, démarre la nouvelle partie

                                                                                scenejeu2.oiseau.monter();
                                                                                i++;
                                                                                if (i == 1){
                                                                                    // Retire le bouton de test de l'écran de jeu après son utilisation
                                                                                    fenetre.getContentPane().remove(btntest2);
                                                                                }

                                                                                // Lance le chronomètre pour le défilement du fond
                                                                                scenejeu2.getchrono().start();

                                                                                // Ajoute un écouteur d'action au bouton de fin de la nouvelle partie
                                                                                btnfin.addActionListener(new ActionListener(){
                                                                                        public void actionPerformed(ActionEvent e){
                                                                                            // Lorsqu'on clique sur le bouton de fin, affiche l'écran de fin de la nouvelle partie
                                                                                            fin = new Fin(nom, scenejeu2.getscore("bird1"), couleur);
                                                                                            fenetre.getContentPane().removeAll();
                                                                                            fenetre.getContentPane().invalidate();
                                                                                            fenetre.setContentPane(fin);
                                                                                            fenetre.getContentPane().revalidate();
                                                                                        }
                                                                                    });
                                                                            }
                                                                        });
                                                                }
                                                            });
                                                    }
                                                });
                                        }
                                    });
                            }
                        });
                }
            });

        // Ajoute un écouteur d'action au bouton "Début du jeu"
        btndebut.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    // Lorsqu'on clique sur le bouton "Début du jeu", on démarre la partie

                    // Crée une nouvelle instance de Scenejeu (l'écran de jeu)
                    scenejeu = new Scenejeu();

                    // Supprime tous les composants existants du conteneur de la fenêtre
                    fenetre.getContentPane().removeAll();
                    fenetre.getContentPane().invalidate();

                    // Définit le panneau de jeu comme nouveau contenu de la fenêtre
                    fenetre.setContentPane(scenejeu);
                    fenetre.getContentPane().revalidate();

                    // Configure la fenêtre : non redimensionnable, toujours au-dessus, et avec la fermeture standard
                    fenetre.setResizable(false);
                    fenetre.setAlwaysOnTop(true);
                    fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    fenetre.setVisible(true);

                    // Crée un bouton pour commencer la partie et l'ajoute au panneau de jeu
                    JButton btntest = new JButton("Appuyer pour commencer");
                    fenetre.getContentPane().add(btntest);
                    btntest.setBounds(100, 350, 200, 50);

                    // Crée un bouton pour finir la partie, mais ne l'ajoute pas encore au panneau
                    btnfin = new JButton("fin");

                    // Ajoute un écouteur d'action au bouton de test
                    btntest.addActionListener(new ActionListener(){
                            public void actionPerformed(ActionEvent e){
                                // Lorsqu'on clique sur le bouton de test, on commence réellement le jeu

                                // Appelle la méthode 'monter' pour faire commencer l'oiseau
                                scenejeu.oiseau.monter();

                                // Incrémente le compteur pour s'assurer que le bouton de test n'est ajouté qu'une fois
                                i++;
                                if (i == 1){
                                    // Retire le bouton de test de l'écran de jeu après son utilisation
                                    fenetre.getContentPane().remove(btntest);
                                }

                                // Démarre le chronomètre pour faire défiler le fond du jeu
                                scenejeu.getchrono().start();

                                // Ajoute un écouteur d'action au bouton de fin
                                btnfin.addActionListener(new ActionListener(){
                                        public void actionPerformed(ActionEvent e){
                                            // Lorsqu'on clique sur le bouton de fin, on affiche l'écran de fin avec le score

                                            // Crée une nouvelle instance de Fin avec le nom du joueur, le score et la couleur de l'oiseau
                                            fin = new Fin(nom, scenejeu.getscore("bird1"), couleur);

                                            // Supprime tous les composants existants du conteneur de la fenêtre
                                            fenetre.getContentPane().removeAll();
                                            fenetre.getContentPane().invalidate();

                                            // Définit le panneau de fin comme nouveau contenu de la fenêtre
                                            fenetre.setContentPane(fin);
                                            fenetre.getContentPane().revalidate();

                                            // Crée des boutons pour recommencer, arrêter ou changer la difficulté
                                            JButton btnrecommencer = new JButton("Voulez vous recommencer ?");
                                            fenetre.getContentPane().add(btnrecommencer);
                                            btnrecommencer.setBounds(100, 350, 200, 50);

                                            JButton btnarreter = new JButton("Voulez vous arrêter ?");
                                            fenetre.getContentPane().add(btnarreter);
                                            btnarreter.setBounds(100, 400, 200, 50);

                                            JButton btnchgtdif = new JButton("Voulez vous changer la difficulté ?");
                                            fenetre.getContentPane().add(btnchgtdif);
                                            btnchgtdif.setBounds(100, 450, 200, 50);

                                            // Ajoute un écouteur d'action au bouton d'arrêt
                                            btnarreter.addActionListener(new ActionListener(){
                                                    public void actionPerformed(ActionEvent e){
                                                        // Lorsqu'on clique sur le bouton d'arrêt, ferme la fenêtre du jeu
                                                        fenetre.dispose();
                                                        jeuEnCours = false; // Met à jour l'état du jeu
                                                        System.out.println("test--------");
                                                        System.out.println(jeuEnCours);
                                                    }
                                                });

                                            // Ajoute un écouteur d'action au bouton de recommencement
                                            btnrecommencer.addActionListener(new ActionListener(){
                                                    public void actionPerformed(ActionEvent e){
                                                        // Lorsqu'on clique sur le bouton de recommencement, redémarre le jeu

                                                        Q = 1; // Indique qu'une nouvelle partie commence
                                                        i = 0; // Réinitialise le compteur pour le bouton de test

                                                        // Crée une nouvelle instance de Scenejeu pour la nouvelle partie
                                                        scenejeu2 = new Scenejeu();

                                                        // Supprime tous les composants existants du conteneur de la fenêtre
                                                        fenetre.getContentPane().removeAll();
                                                        fenetre.getContentPane().invalidate();

                                                        // Définit le panneau de jeu comme nouveau contenu de la fenêtre
                                                        fenetre.setContentPane(scenejeu2);
                                                        fenetre.getContentPane().revalidate();

                                                        // Configure la fenêtre : non redimensionnable, toujours au-dessus, et avec la fermeture standard
                                                        fenetre.setResizable(false);
                                                        fenetre.setAlwaysOnTop(true);
                                                        fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                                        fenetre.setVisible(true);

                                                        // Crée un bouton pour commencer la partie dans la nouvelle instance de Scenejeu
                                                        JButton btntest2 = new JButton("Appuyer pour commencer");
                                                        fenetre.getContentPane().add(btntest2);
                                                        btntest2.setBounds(100, 350, 200, 50);

                                                        // Ajoute un écouteur d'action au nouveau bouton de test
                                                        btntest2.addActionListener(new ActionListener(){
                                                                public void actionPerformed(ActionEvent e){
                                                                    // Lorsqu'on clique sur le bouton de test de la nouvelle partie, commence la nouvelle partie

                                                                    scenejeu2.oiseau.monter();
                                                                    i++;
                                                                    if (i == 1){
                                                                        // Retire le bouton de test de l'écran de jeu après son utilisation
                                                                        fenetre.getContentPane().remove(btntest2);
                                                                    }

                                                                    // Démarre le chronomètre pour faire défiler le fond du jeu
                                                                    scenejeu2.getchrono().start();

                                                                    // Ajoute un écouteur d'action au bouton de fin de la nouvelle partie
                                                                    btnfin.addActionListener(new ActionListener(){
                                                                            public void actionPerformed(ActionEvent e){
                                                                                // Lorsqu'on clique sur le bouton de fin de la nouvelle partie, affiche l'écran de fin
                                                                                fin = new Fin(nom, scenejeu2.getscore("bird1"), couleur);
                                                                                fenetre.getContentPane().removeAll();
                                                                                fenetre.getContentPane().invalidate();
                                                                                fenetre.setContentPane(fin);
                                                                                fenetre.getContentPane().revalidate();
                                                                            }
                                                                        });
                                                                }
                                                            });
                                                    }
                                                });

                                            // Ajoute un écouteur d'action au bouton pour changer la difficulté
                                            btnchgtdif.addActionListener(new ActionListener(){
                                                    public void actionPerformed(ActionEvent e){
                                                        // Lorsqu'on clique sur le bouton de changement de difficulté, redémarre le jeu avec une nouvelle difficulté
                                                        fenetre.dispose(); // Ferme la fenêtre actuelle
                                                        i = 0; // Réinitialise le compteur pour le bouton de test
                                                        Main(); // Relance la méthode Main pour réinitialiser l'état du jeu
                                                    }
                                                });
                                        }
                                    });
                            }
                        });

                    // Définit la position initiale de la fenêtre sur l'écran
                    fenetre.setLocation(140, 70);
                }
            });
    }

    // Cette méthode ajoute un bouton à la fenêtre principale
    public static void ajouterbouton(JButton btn){
        // Ajoute le bouton au conteneur de la fenêtre
        fenetre.getContentPane().add(btn);
    }

    // Cette méthode retourne la couleur choisie par le joueur si le mot de passe est correct
    public static int getcouleur(String mdp){
        // Vérifie si le mot de passe fourni est égal à "bird1"
        if(mdp == "bird1"){
            // Si oui, retourne la couleur choisie par le joueur
            return couleur;
        }
        else{
            // Sinon, retourne 0 pour indiquer qu'aucune couleur n'est sélectionnée
            return 0;
        }
    }

    // Cette méthode retourne le poids choisi par le joueur si le mot de passe est correct
    public static int getpoids(String mdp){
        // Vérifie si le mot de passe fourni est égal à "bird1"
        if(mdp == "bird1"){
            // Si oui, retourne le poids choisi par le joueur
            return poids;
        }
        else{
            // Sinon, retourne 0 pour indiquer qu'aucun poids n'est sélectionné
            return 0;
        }
    }

    // Cette méthode permet de savoir si c'est la première partie ou si le joueur a déjà recommencé une ou plusieurs parties
    public static int getQ(String mdp){
        // Vérifie si le mot de passe fourni est égal à "bird1"
        if(mdp == "bird1"){
            // Si oui, retourne la valeur de Q (qui indique le nombre de parties jouées ou recommencées)
            return Q;
        }
        else{
            // Sinon, retourne 0 pour indiquer qu'il n'y a pas de données disponibles
            return 0;
        }
    }

}
